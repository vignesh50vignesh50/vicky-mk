# Inventory Management System

A simple Inventory Management System built with Python and Django.

## Features

- Dashboard with stock and inventory statistics
- Product management
- Category management
- Supplier management
- Stock IN / OUT transactions
- Automatic stock quantity updates
- Low-stock and out-of-stock alerts
- Search products
- SQLite database
- Django Admin support

## Setup

```bash
python -m venv venv
```

### Windows

```bash
venv\Scripts\activate
```

### Linux / macOS

```bash
source venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Create database:

```bash
python manage.py makemigrations
python manage.py migrate
```

Create an admin user:

```bash
python manage.py createsuperuser
```

Run the server:

```bash
python manage.py runserver
```

Open:

- Application: http://127.0.0.1:8000/
- Admin: http://127.0.0.1:8000/admin/

## Project structure

```text
inventory_management_system/
├── manage.py
├── requirements.txt
├── README.md
├── inventory_project/
│   ├── settings.py
│   ├── urls.py
│   ├── wsgi.py
│   └── asgi.py
└── inventory/
    ├── admin.py
    ├── apps.py
    ├── forms.py
    ├── models.py
    ├── urls.py
    ├── views.py
    ├── migrations/
    └── templates/
        └── inventory/
            ├── base.html
            ├── dashboard.html
            ├── product_list.html
            ├── product_form.html
            ├── category_list.html
            ├── category_form.html
            ├── supplier_list.html
            ├── supplier_form.html
            ├── transaction_list.html
            └── transaction_form.html
```
