from django.contrib import admin
from .models import Category, Product, Supplier, StockTransaction

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name",)
    search_fields = ("name",)


@admin.register(Supplier)
class SupplierAdmin(admin.ModelAdmin):
    list_display = ("name", "phone", "email")
    search_fields = ("name", "phone", "email")


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("sku", "name", "category", "supplier", "quantity", "reorder_level", "selling_price", "status")
    list_filter = ("category", "supplier")
    search_fields = ("sku", "name")


@admin.register(StockTransaction)
class StockTransactionAdmin(admin.ModelAdmin):
    list_display = ("product", "transaction_type", "quantity", "reference", "created_at")
    list_filter = ("transaction_type", "created_at")
    search_fields = ("product__name", "product__sku", "reference")
