from django import forms
from .models import Category, Product, Supplier, StockTransaction

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = [
            "sku", "name", "category", "supplier", "description",
            "purchase_price", "selling_price", "quantity", "reorder_level"
        ]
        widgets = {
            "description": forms.Textarea(attrs={"rows": 3}),
        }


class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ["name", "description"]
        widgets = {"description": forms.Textarea(attrs={"rows": 3})}


class SupplierForm(forms.ModelForm):
    class Meta:
        model = Supplier
        fields = ["name", "phone", "email", "address"]
        widgets = {"address": forms.Textarea(attrs={"rows": 3})}


class StockTransactionForm(forms.ModelForm):
    class Meta:
        model = StockTransaction
        fields = ["product", "transaction_type", "quantity", "reference", "notes"]
        widgets = {"notes": forms.Textarea(attrs={"rows": 3})}

    def clean(self):
        cleaned = super().clean()
        product = cleaned.get("product")
        transaction_type = cleaned.get("transaction_type")
        quantity = cleaned.get("quantity")

        if product and transaction_type == StockTransaction.OUT and quantity:
            if quantity > product.quantity:
                raise forms.ValidationError(
                    f"Insufficient stock. Available quantity: {product.quantity}."
                )
        return cleaned
