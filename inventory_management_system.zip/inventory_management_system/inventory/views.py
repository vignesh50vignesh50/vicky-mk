from django.contrib import messages
from django.db import transaction
from django.db.models import F, Q, Sum
from django.shortcuts import get_object_or_404, redirect, render

from .forms import CategoryForm, ProductForm, SupplierForm, StockTransactionForm
from .models import Category, Product, Supplier, StockTransaction


def dashboard(request):
    products = Product.objects.select_related("category", "supplier")
    low_stock = products.filter(quantity__gt=0, quantity__lte=F("reorder_level"))
    out_of_stock = products.filter(quantity=0)
    stock_value = products.aggregate(total=Sum(F("quantity") * F("purchase_price")))["total"] or 0

    context = {
        "product_count": products.count(),
        "category_count": Category.objects.count(),
        "supplier_count": Supplier.objects.count(),
        "low_stock_count": low_stock.count(),
        "out_of_stock_count": out_of_stock.count(),
        "stock_value": stock_value,
        "low_stock_products": low_stock[:8],
        "recent_transactions": StockTransaction.objects.select_related("product")[:8],
    }
    return render(request, "inventory/dashboard.html", context)


def product_list(request):
    query = request.GET.get("q", "").strip()
    products = Product.objects.select_related("category", "supplier")
    if query:
        products = products.filter(
            Q(name__icontains=query) |
            Q(sku__icontains=query) |
            Q(category__name__icontains=query)
        )
    return render(request, "inventory/product_list.html", {"products": products, "query": query})


def product_create(request):
    form = ProductForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, "Product created successfully.")
        return redirect("product_list")
    return render(request, "inventory/product_form.html", {"form": form, "title": "Add Product"})


def product_update(request, pk):
    product = get_object_or_404(Product, pk=pk)
    form = ProductForm(request.POST or None, instance=product)
    if form.is_valid():
        form.save()
        messages.success(request, "Product updated successfully.")
        return redirect("product_list")
    return render(request, "inventory/product_form.html", {"form": form, "title": "Edit Product"})


def product_delete(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == "POST":
        product.delete()
        messages.success(request, "Product deleted successfully.")
        return redirect("product_list")
    return render(request, "inventory/product_list.html", {"products": Product.objects.all(), "delete_confirm": product})


def category_list(request):
    return render(request, "inventory/category_list.html", {"categories": Category.objects.all()})


def category_create(request):
    form = CategoryForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, "Category created successfully.")
        return redirect("category_list")
    return render(request, "inventory/category_form.html", {"form": form, "title": "Add Category"})


def supplier_list(request):
    return render(request, "inventory/supplier_list.html", {"suppliers": Supplier.objects.all()})


def supplier_create(request):
    form = SupplierForm(request.POST or None)
    if form.is_valid():
        form.save()
        messages.success(request, "Supplier created successfully.")
        return redirect("supplier_list")
    return render(request, "inventory/supplier_form.html", {"form": form, "title": "Add Supplier"})


def transaction_list(request):
    transactions = StockTransaction.objects.select_related("product")
    return render(request, "inventory/transaction_list.html", {"transactions": transactions})


@transaction.atomic
def transaction_create(request):
    form = StockTransactionForm(request.POST or None)
    if form.is_valid():
        stock_tx = form.save(commit=False)
        product = Product.objects.select_for_update().get(pk=stock_tx.product_id)

        if stock_tx.transaction_type == StockTransaction.IN:
            product.quantity = F("quantity") + stock_tx.quantity
        else:
            if stock_tx.quantity > product.quantity:
                form.add_error("quantity", f"Only {product.quantity} units are available.")
                return render(request, "inventory/transaction_form.html", {"form": form, "title": "Stock Transaction"})
            product.quantity = F("quantity") - stock_tx.quantity

        product.save(update_fields=["quantity", "updated_at"])
        product.refresh_from_db()

        stock_tx.save()
        messages.success(request, "Stock transaction recorded successfully.")
        return redirect("transaction_list")

    return render(request, "inventory/transaction_form.html", {"form": form, "title": "Stock Transaction"})
